### 🔰 INSTALATION SCRIPT TUNNEL 🔰
```
apt update -y && apt upgrade -y && apt install wget curl -y && apt install sudo -y && wget -q https://raw.githubusercontent.com/Satria5560/v3/main/setup-deb10-ub20.sh && chmod +x setup-deb10-ub20.sh && ./setup-deb10-ub20.sh
```
### 🔰 UPDATE SCRIPT TUNNEL 🔰
```
wget -q https://raw.githubusercontent.com/Satria5560/v3/main/update.sh && chmod +x update.sh && ./update.sh
```
### ⚠️ SATRIA TUNNELING (OWNER) ⚠️
